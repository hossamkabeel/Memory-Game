# Memory Game Project
In Front-End Web Developer Nanodegree course, I made a project of the Memory Game Which is about 16 cards and when pressing on two similar remain visible until the end where all the symbols appeared and show a congratulatory message At the same time, the game calculates the time taken, the number of steps, and the stars.

# How to start
This project contains the following files:
index.html
app.css
app.js
After loading the project files form https://github.com/udacity/fend-project-memory-game in my udacity classroom, I have done the simple modifications in the index.html file and the app.css file and the app.js file where most of the code needed to run the game.

#about me
Hossam Kabeel
hossamkabeel@hotmail.com
